#include "jx_uart_send.h"

// UART0_RX串口通信消息头
const unsigned char g_uart_send_head_UART0_RX[] = {
  0xaa, 0x55
};

// UART0_RX串口通信消息尾
const unsigned char g_uart_send_foot_UART0_RX[] = {
  0x55, 0xaa
};

// 串口发送函数实现
void _uart_send_impl(int port, unsigned char* buff, int len) {
  // TODO: 调用项目实际的串口发送函数
  /*
  int i = 0;
  unsigned char c;
  for (i = 0; i < len; i++) {
    c = buff[i];
    printf("%02X ", c);
  }
  printf("\n");
  */
}

// action: announce
void _uart_announce() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_announce;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: zero_1
void _uart_zero_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_zero_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: one_1
void _uart_one_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_one_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: two1
void _uart_two1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_two1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: three_1
void _uart_three_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_three_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: four_1
void _uart_four_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_four_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: five_1
void _uart_five_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_five_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: six_1
void _uart_six_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_six_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: seven_1
void _uart_seven_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_seven_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: eight_1
void _uart_eight_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_eight_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: nine_1
void _uart_nine_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_nine_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

// action: ten_1
void _uart_ten_1() {
  uart_param_t param;
  int i = 0;
  unsigned char buff[UART_SEND_MAX] = {0};
  for (i = 0; i < UART_MSG_HEAD_LEN_UART0_RX; i++) {
      buff[i + 0] = g_uart_send_head_UART0_RX[i];
  }
  buff[2] = U_MSG_ten_1;
  for (i = 0; i < UART_MSG_FOOT_LEN_UART0_RX; i++) {
      buff[i + 3] = g_uart_send_foot_UART0_RX[i];
  }
  _uart_send_impl(0, buff, 5);
}

